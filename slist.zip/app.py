from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

# In-memory storage for students
students = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/students', methods=['GET'])
def get_students():
    return jsonify(students)

@app.route('/api/students', methods=['POST'])
def add_student():
    data = request.json
    if data.get('name') and data.get('address') and data.get('phone'):
        students.append(data)
        return jsonify({'message': 'Student added successfully!', 'student': data}), 201
    return jsonify({'message': 'Invalid data!'}), 400

@app.route('/api/students/<int:index>', methods=['DELETE'])
def delete_student(index):
    if 0 <= index < len(students):
        deleted_student = students.pop(index)
        return jsonify({'message': 'Student deleted successfully!', 'student': deleted_student}), 200
    return jsonify({'message': 'Student not found!'}), 404

if __name__ == '__main__':
    app.run(debug=True)
