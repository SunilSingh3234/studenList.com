const studentTable = document.getElementById('studentTable').querySelector('tbody');
const addBtn = document.getElementById('addBtn');

// Fetch and display students
async function fetchStudents() {
    const response = await fetch('/api/students');
    const students = await response.json();

    // Clear the table
    studentTable.innerHTML = '';

    // Add rows to the table
    students.forEach((student, index) => {
        addStudentToTable(student, index);
    });
}

// Add a student to the table
function addStudentToTable(student, index) {
    const row = document.createElement('tr');

    row.innerHTML = `
        <td>${index + 1}</td>
        <td>${student.name}</td>
        <td>${student.address}</td>
        <td>${student.phone}</td>
        <td>
            <button class="deleteBtn" onclick="deleteStudent(${index})">Delete</button>
        </td>
    `;

    studentTable.appendChild(row);
}

// Add a new student
addBtn.addEventListener('click', async () => {
    const name = document.getElementById('name').value.trim();
    const address = document.getElementById('address').value.trim();
    const phone = document.getElementById('phone').value.trim();

    if (name && address && phone) {
        const response = await fetch('/api/students', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, address, phone })
        });

        if (response.ok) {
            await fetchStudents();
            document.getElementById('name').value = '';
            document.getElementById('address').value = '';
            document.getElementById('phone').value = '';
        } else {
            alert('Failed to add student.');
        }
    } else {
        alert('Please fill all fields.');
    }
});

// Delete a student
async function deleteStudent(index) {
    const response = await fetch(`/api/students/${index}`, { method: 'DELETE' });

    if (response.ok) {
        await fetchStudents();
    } else {
        alert('Failed to delete student.');
    }
}

// Initial fetch
fetchStudents();
